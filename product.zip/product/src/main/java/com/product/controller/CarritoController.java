package com.product.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.product.exceptions.BadResourceException;
import com.product.exceptions.ResourceAlreadyExistsException;
import com.product.exceptions.ResourceNotFoundException;
import com.product.model.CarritoCompras;
import com.product.model.DetalleVenta;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class CarritoController {
	
	@Autowired
	CarritoCompras carrito;
	
	@GetMapping(value = "/carrito", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ArrayList<DetalleVenta>> findAll() {
		return ResponseEntity.ok(carrito.getCarrito());
	}
	
	@DeleteMapping(value = "/carrito/{Id}")
    @ExceptionHandler(value = ResourceNotFoundException.class)
    public ResponseEntity<Object> deleteProduct(@PathVariable long Id) {
        try {
        	carrito.borrarItem((int) Id);
            return ResponseEntity.ok().build();
        } catch (ResourceNotFoundException ex) {
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
	
	@PostMapping(path = "/product", consumes = "application/json", produces = "application/json")
    public ResponseEntity<DetalleVenta> saveProduct( @RequestBody DetalleVenta dv) 
            throws URISyntaxException {
        try {
        	carrito.agregarItem(dv);
            return ResponseEntity.created(new URI("/api/showproduct/" +dv.getCodigoVenta()))
                    .body(dv);
        } catch (ResourceAlreadyExistsException ex) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
    }
	

}
